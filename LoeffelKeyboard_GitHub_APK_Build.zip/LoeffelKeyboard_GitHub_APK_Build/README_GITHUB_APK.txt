So baust du die APK nur mit Handy und GitHub:

1. Öffne github.com im Browser.
2. Neues Repository erstellen, z.B. LoeffelKeyboard.
3. Diese ZIP entpacken.
4. ALLE Dateien/Ordner aus dem entpackten Ordner ins Repository hochladen:
   - app
   - build.gradle
   - settings.gradle
   - gradle
   - .github
   - gradlew / gradlew.bat (egal, GitHub nutzt gradle direkt)
5. Nach dem Hochladen oben auf "Actions" tippen.
6. Workflow "Build Android APK" öffnen.
7. Falls er nicht automatisch startet: "Run workflow" drücken.
8. Warten bis ein grüner Haken erscheint.
9. Den fertigen Build öffnen und unten bei "Artifacts" herunterladen:
   LoeffelKeyboard-debug-apk
10. ZIP entpacken, darin liegt die APK.
11. APK auf dem Handy installieren.
12. Tastatur aktivieren:
   Einstellungen > System > Tastatur > Bildschirmtastatur > Tastaturen verwalten > LoeffelKeyboard aktivieren.

Hinweis: Wenn GitHub fragt, ob Actions erlaubt werden sollen, erlauben.
