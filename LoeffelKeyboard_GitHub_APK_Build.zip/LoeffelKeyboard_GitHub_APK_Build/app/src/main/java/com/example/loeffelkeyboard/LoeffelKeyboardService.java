package com.example.loeffelkeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoeffelKeyboardService extends InputMethodService {
    private TextView preview;

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10, 10, 10, 10);

        preview = new TextView(this);
        preview.setText("Löffelsprache Tastatur");
        preview.setTextSize(18);
        preview.setGravity(Gravity.CENTER);
        root.addView(preview, new LinearLayout.LayoutParams(-1, -2));

        addRow(root, "qwertzuiop");
        addRow(root, "asdfghjkl");
        addRow(root, "yxcvbnm");
        addSpecialRow(root);
        return root;
    }

    private void addRow(LinearLayout root, String chars) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < chars.length(); i++) {
            final char c = chars.charAt(i);
            Button b = new Button(this);
            b.setText(String.valueOf(c));
            b.setOnClickListener(v -> commit(toLoeffel(String.valueOf(c))));
            row.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(row);
    }

    private void addSpecialRow(LinearLayout root) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button space = new Button(this); space.setText("Leer"); space.setOnClickListener(v -> commit(" "));
        Button del = new Button(this); del.setText("⌫"); del.setOnClickListener(v -> { InputConnection ic = getCurrentInputConnection(); if (ic != null) ic.deleteSurroundingText(1, 0); });
        Button enter = new Button(this); enter.setText("↵"); enter.setOnClickListener(v -> commit("\n"));
        row.addView(space, new LinearLayout.LayoutParams(0, -2, 2));
        row.addView(del, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(enter, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);
    }

    private void commit(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(text, 1);
        if (preview != null) preview.setText(text.equals(" ") ? "Leerzeichen" : text);
    }

    private String toLoeffel(String input) {
        String vowels = "aeiouäöüAEIOUÄÖÜ";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            out.append(c);
            if (vowels.indexOf(c) >= 0) {
                out.append("löff");
                out.append(Character.toLowerCase(c));
            }
        }
        return out.toString();
    }
}
