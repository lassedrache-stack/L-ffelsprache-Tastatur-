package com.example.loeffelkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("Löffel Tastatur\n\n1. Tastatur aktivieren\n2. Beim Schreiben auswählen\n\nDann wird Text automatisch in Löffelsprache geschrieben.");
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        Button settings = new Button(this);
        settings.setText("Tastatur-Einstellungen öffnen");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        layout.addView(settings);

        setContentView(layout);
    }
}
