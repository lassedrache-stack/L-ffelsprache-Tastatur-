SO BAUST DU DIE APK AUF DEM HANDY

1. Diese ZIP entpacken.
2. Android IDE - PHONE AS öffnen.
3. Open Project / Projekt öffnen.
4. Den entpackten Ordner LoeffelKeyboard_AndroidIDE auswählen.
5. Oben auf Play drücken ODER Terminal öffnen und eingeben:
   ./gradlew assembleDebug
6. Die APK liegt danach hier:
   app/build/outputs/apk/debug/app-debug.apk

Nach Installation:
Einstellungen > System > Tastatur > Bildschirmtastatur > Tastaturen verwalten > Löffel Tastatur aktivieren.
Dann beim Schreiben die Tastatur wechseln.
